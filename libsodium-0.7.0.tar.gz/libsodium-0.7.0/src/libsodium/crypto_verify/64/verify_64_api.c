#include "crypto_verify_64.h"

size_t
crypto_verify_64_bytes(void) {
    return crypto_verify_64_BYTES;
}
